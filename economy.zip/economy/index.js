const fs = require('fs');
const path = require('path');
const config = require('./config');
const { startLotteryScheduler } = require('./lotteryManager');

const commands = new Map();
const commandsPath = path.join(__dirname, 'commands');

for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
    const command = require(path.join(commandsPath, file));
    commands.set(command.name, command);
    if (command.aliases) {
        for (const alias of command.aliases) commands.set(alias, command);
    }
}

// Mevcut messageCreate event'inizin İÇİNE bu fonksiyonu çağırın.
// true dönerse mesaj bir ekonomi komutuydu ve işlendi demektir.
async function handleEconomyMessage(message) {
    if (message.author.bot) return false;
    if (!message.content.startsWith(config.PREFIX)) return false;

    const args = message.content.slice(config.PREFIX.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();
    const command = commands.get(commandName);

    if (!command) return false;

    try {
        await command.execute(message, args);
    } catch (err) {
        console.error('[economy]', err);
        message.reply('❌ Komut çalıştırılırken bir hata oluştu.').catch(() => {});
    }
    return true;
}

module.exports = { handleEconomyMessage, startLotteryScheduler };
