# Ekonomi & Kumar Sistemi — Kurulum

## 1. Dosyaları yerleştir
`economy` klasörünü, mevcut botunun ana `index.js` (veya `bot.js`) dosyasıyla
**aynı seviyeye** koy. Örnek proje yapısı:

```
bot/
├── index.js          <- senin mevcut ana dosyan
├── economy/           <- bu paket
│   ├── config.js
│   ├── db.js
│   ├── utils.js
│   ├── index.js
│   ├── lotteryManager.js
│   └── commands/
│       ├── para.js
│       ├── daily.js
│       ├── coinflip.js
│       ├── zar.js
│       ├── slot.js
│       ├── blackjack.js
│       └── piyango.js
```

## 2. Gerekli paket
Blackjack butonları için discord.js v14 gerekli (`ActionRowBuilder`, `ButtonBuilder`).
Zaten discord.js kullandığın için ek bir paket kurmana gerek yok.

## 3. Mevcut botuna bağla
Ana dosyanda (`index.js`), `messageCreate` event'inin olduğu yere şunu ekle:

```js
const { handleEconomyMessage, startLotteryScheduler } = require('./economy');

client.on('messageCreate', async (message) => {
    // Önce ekonomi komutlarını kontrol et
    const handled = await handleEconomyMessage(message);
    if (handled) return;

    // ... senin mevcut komutların burada devam ediyor
});

client.once('ready', () => {
    // İkinci parametre opsiyonel: piyango sonuçlarının duyurulacağı kanal ID'si.
    // Boş bırakırsan sadece arka planda çekiliş yapılır, duyuru gönderilmez.
    startLotteryScheduler(client, 'DUYURU_KANAL_ID');
});
```

Eğer botun zaten kendi komut handler'ı varsa (klasörden komut okuyorsa),
`economy/commands/*.js` dosyalarını doğrudan kendi `commands` klasörüne
kopyalayıp `db.js`, `config.js`, `utils.js` dosyalarına oradan
`require('../../economy/db')` gibi yollarla erişebilirsin. En kolayı ise
yukarıdaki gibi `handleEconomyMessage` fonksiyonunu en başta çağırmak.

## 4. Komutlar
| Komut | Açıklama |
|---|---|
| `!para [@kullanıcı]` | Bakiye gösterir |
| `!daily` | 24 saatte bir günlük ödül (500–2000 arası) |
| `!coinflip <miktar> <yazi/tura>` | Yazı tura, 2 kat |
| `!zar <miktar> <tek/cift>` | Tek/çift tahmini, 2 kat |
| `!zar <miktar> <1-6>` | Tam sayı tahmini, 6 kat |
| `!slot <miktar>` | Slot makinesi, 3 aynı sembol büyük ödül |
| `!blackjack <miktar>` | 21 oyunu, butonlarla kart çek/dur |
| `!piyango` | Piyango durumunu gösterir |
| `!piyango al <adet>` | Bilet satın al (bilet başı 1000) |
| `!piyango gecmis` | Son kazananlar |

Tüm oyunlarda bahis miktarı yerine `hepsi` yazarsan tüm bakiyeni yatırırsın.

## 5. Ayarlar
`economy/config.js` içinden şunları değiştirebilirsin:
- `MAX_BET`: 250000 (istenen üst limit, tüm oyunlar için ortak)
- `DAILY_MIN` / `DAILY_MAX`: günlük ödül aralığı
- `LOTTERY_TICKET_PRICE`: piyango bilet fiyatı
- `LOTTERY_DRAW_INTERVAL`: çekiliş sıklığı (ms)
- `STARTING_BALANCE`: yeni kullanıcıların başlangıç bakiyesi

## 6. Veri saklama
Veriler `economy/economy.json` ve `economy/lottery.json` dosyalarında JSON
olarak tutulur, ek bir veritabanı kurmana gerek yok. Bu iki dosyayı
`.gitignore`'a eklemen önerilir ki her `git pull` sonrası bakiyeler
sıfırlanmasın:

```
economy/economy.json
economy/lottery.json
```
