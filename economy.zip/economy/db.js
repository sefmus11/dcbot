const fs = require('fs');
const path = require('path');
const config = require('./config');

const DB_PATH = path.join(__dirname, 'economy.json');
const LOTTERY_PATH = path.join(__dirname, 'lottery.json');

function loadData(filePath, defaultData) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
        return defaultData;
    }
    try {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch (e) {
        return defaultData;
    }
}

let users = loadData(DB_PATH, {});
let lottery = loadData(LOTTERY_PATH, {
    pool: 0,
    tickets: [],
    nextDraw: Date.now() + config.LOTTERY_DRAW_INTERVAL,
    history: []
});

function saveUsers() {
    fs.writeFileSync(DB_PATH, JSON.stringify(users, null, 2));
}

function saveLottery() {
    fs.writeFileSync(LOTTERY_PATH, JSON.stringify(lottery, null, 2));
}

function getUser(userId) {
    if (!users[userId]) {
        users[userId] = {
            balance: config.STARTING_BALANCE,
            lastDaily: 0,
            stats: { won: 0, lost: 0, gamesPlayed: 0 }
        };
        saveUsers();
    }
    // eski kayıtlarda stats yoksa ekle
    if (!users[userId].stats) {
        users[userId].stats = { won: 0, lost: 0, gamesPlayed: 0 };
    }
    return users[userId];
}

function updateBalance(userId, amount) {
    const user = getUser(userId);
    user.balance += amount;
    if (user.balance < 0) user.balance = 0;
    saveUsers();
    return user.balance;
}

function setBalance(userId, amount) {
    const user = getUser(userId);
    user.balance = Math.max(0, amount);
    saveUsers();
    return user.balance;
}

function recordGame(userId, won) {
    const user = getUser(userId);
    user.stats.gamesPlayed++;
    if (won) user.stats.won++; else user.stats.lost++;
    saveUsers();
}

module.exports = {
    getUser,
    updateBalance,
    setBalance,
    recordGame,
    saveUsers,
    lottery,
    saveLottery
};
