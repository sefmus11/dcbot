const db = require('../db');
const { parseBet, validateBet, formatMoney } = require('../utils');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

function createDeck() {
    const suits = ['♠', '♥', '♦', '♣'];
    const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck = [];
    for (const s of suits) for (const v of values) deck.push({ suit: s, value: v });
    return deck.sort(() => Math.random() - 0.5);
}

function cardValue(card) {
    if (['J', 'Q', 'K'].includes(card.value)) return 10;
    if (card.value === 'A') return 11;
    return parseInt(card.value, 10);
}

function handValue(hand) {
    let total = hand.reduce((s, c) => s + cardValue(c), 0);
    let aces = hand.filter(c => c.value === 'A').length;
    while (total > 21 && aces > 0) {
        total -= 10;
        aces--;
    }
    return total;
}

function formatHand(hand) {
    return hand.map(c => `${c.value}${c.suit}`).join(' ');
}

module.exports = {
    name: 'blackjack',
    aliases: ['bj', '21'],
    description: 'Blackjack oyunu. Kullanım: !blackjack <miktar>',
    async execute(message, args) {
        const user = db.getUser(message.author.id);
        const amount = parseBet(args[0], user.balance);

        if (!amount) return message.reply('Geçerli bir miktar gir. Örnek: `!blackjack 1000`');
        const err = validateBet(amount, user.balance);
        if (err) return message.reply(err);

        const deck = createDeck();
        const playerHand = [deck.pop(), deck.pop()];
        const dealerHand = [deck.pop(), deck.pop()];

        const playerBJ = handValue(playerHand) === 21;
        const dealerBJ = handValue(dealerHand) === 21;

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('hit').setLabel('Kart Çek').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('stand').setLabel('Dur').setStyle(ButtonStyle.Secondary)
        );

        const buildEmbed = (revealDealer = false, resultText = null) => {
            const embed = new EmbedBuilder()
                .setColor('#2c3e50')
                .setTitle('🃏 Blackjack')
                .addFields(
                    { name: `Senin Elin (${handValue(playerHand)})`, value: formatHand(playerHand) },
                    {
                        name: revealDealer ? `Kurpiyer (${handValue(dealerHand)})` : 'Kurpiyer',
                        value: revealDealer ? formatHand(dealerHand) : `${formatHand([dealerHand[0]])} 🂠`
                    }
                )
                .setFooter({ text: `Bahis: ${amount.toLocaleString('tr-TR')}` });
            if (resultText) embed.setDescription(resultText);
            return embed;
        };

        const msg = await message.reply({
            embeds: [buildEmbed()],
            components: playerBJ || dealerBJ ? [] : [row]
        });

        async function finish(interaction) {
            while (handValue(dealerHand) < 17) dealerHand.push(deck.pop());

            const playerTotal = handValue(playerHand);
            const dealerTotal = handValue(dealerHand);
            let result, change;

            if (playerTotal > 21) {
                result = '💥 Battın! Kaybettin.';
                change = -amount;
            } else if (playerBJ && !dealerBJ) {
                result = '🎉 Blackjack! Kazandın!';
                change = Math.floor(amount * 1.5);
            } else if (dealerTotal > 21) {
                result = '🎉 Kurpiyer battı! Kazandın!';
                change = amount;
            } else if (playerTotal > dealerTotal) {
                result = '🎉 Kazandın!';
                change = amount;
            } else if (playerTotal < dealerTotal) {
                result = '😔 Kaybettin.';
                change = -amount;
            } else {
                result = '🤝 Berabere! Bahsin iade edildi.';
                change = 0;
            }

            db.updateBalance(message.author.id, change);
            if (change !== 0) db.recordGame(message.author.id, change > 0);

            const finalEmbed = buildEmbed(
                true,
                `${result}${change !== 0 ? `\n${change > 0 ? '+' : ''}${formatMoney(change)}` : ''}\n` +
                `Güncel bakiye: **${db.getUser(message.author.id).balance.toLocaleString('tr-TR')}**`
            );

            if (interaction) {
                await interaction.update({ embeds: [finalEmbed], components: [] });
            } else {
                await msg.edit({ embeds: [finalEmbed], components: [] });
            }
        }

        if (playerBJ || dealerBJ) {
            return finish(null);
        }

        const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === message.author.id,
            time: 30000
        });

        collector.on('collect', async i => {
            if (i.customId === 'hit') {
                playerHand.push(deck.pop());
                if (handValue(playerHand) >= 21) {
                    collector.stop('done');
                    return finish(i);
                }
                await i.update({ embeds: [buildEmbed()], components: [row] });
            } else {
                collector.stop('done');
                finish(i);
            }
        });

        collector.on('end', (collected, reason) => {
            if (reason !== 'done') {
                msg.edit({ components: [] }).catch(() => {});
            }
        });
    }
};
