const db = require('../db');
const config = require('../config');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'daily',
    aliases: ['gunluk'],
    description: 'Günlük ödülünü alır. Kullanım: !daily',
    async execute(message) {
        const user = db.getUser(message.author.id);
        const now = Date.now();
        const remaining = user.lastDaily + config.DAILY_COOLDOWN - now;

        if (remaining > 0) {
            const hours = Math.floor(remaining / 3600000);
            const minutes = Math.floor((remaining % 3600000) / 60000);
            return message.reply(`⏳ Günlük ödülünü zaten aldın! Yeni ödül için **${hours} saat ${minutes} dakika** beklemelisin.`);
        }

        const amount = Math.floor(Math.random() * (config.DAILY_MAX - config.DAILY_MIN + 1)) + config.DAILY_MIN;
        user.lastDaily = now;
        db.updateBalance(message.author.id, amount);
        db.saveUsers();

        const embed = new EmbedBuilder()
            .setColor('#f1c40f')
            .setDescription(
                `🎁 Günlük ödülünü aldın: **${amount.toLocaleString('tr-TR')}** ${config.CURRENCY_EMOJI}\n` +
                `Güncel bakiye: **${db.getUser(message.author.id).balance.toLocaleString('tr-TR')}**`
            );

        message.reply({ embeds: [embed] });
    }
};
