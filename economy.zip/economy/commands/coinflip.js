const db = require('../db');
const { parseBet, validateBet, formatMoney } = require('../utils');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'coinflip',
    aliases: ['cf', 'yazitura'],
    description: 'Yazı tura oyunu. Kullanım: !coinflip <miktar> <yazi/tura>',
    async execute(message, args) {
        const user = db.getUser(message.author.id);
        const amount = parseBet(args[0], user.balance);
        const choice = (args[1] || '').toLowerCase();

        if (!amount) return message.reply('Geçerli bir miktar gir. Örnek: `!coinflip 1000 yazi`');
        const err = validateBet(amount, user.balance);
        if (err) return message.reply(err);
        if (!['yazi', 'tura'].includes(choice)) {
            return message.reply('Yazı mı tura mı seçmelisin! Örnek: `!coinflip 1000 yazi`');
        }

        const result = Math.random() < 0.5 ? 'yazi' : 'tura';
        const won = result === choice;

        db.updateBalance(message.author.id, won ? amount : -amount);
        db.recordGame(message.author.id, won);

        const embed = new EmbedBuilder()
            .setColor(won ? '#2ecc71' : '#e74c3c')
            .setDescription(
                `🪙 Sonuç: **${result === 'yazi' ? 'Yazı' : 'Tura'}**\n` +
                (won ? `Kazandın! +${formatMoney(amount)}` : `Kaybettin! -${formatMoney(amount)}`) +
                `\nGüncel bakiye: **${db.getUser(message.author.id).balance.toLocaleString('tr-TR')}**`
            );

        message.reply({ embeds: [embed] });
    }
};
