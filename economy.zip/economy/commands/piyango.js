const db = require('../db');
const config = require('../config');
const { formatMoney } = require('../utils');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'piyango',
    aliases: ['loto', 'lottery'],
    description: 'Piyango sistemi. Kullanım: !piyango | !piyango al <adet>',
    async execute(message, args) {
        const sub = (args[0] || '').toLowerCase();

        if (sub === 'al' || sub === 'buy') {
            const count = parseInt(args[1], 10) || 1;
            if (count <= 0 || count > 100) {
                return message.reply('1 ile 100 arası bilet alabilirsin. Örnek: `!piyango al 5`');
            }

            const user = db.getUser(message.author.id);
            const cost = config.LOTTERY_TICKET_PRICE * count;

            if (user.balance < cost) {
                return message.reply(`Yeterli bakiyen yok! ${formatMoney(cost)} gerekiyor, bakiyen: ${formatMoney(user.balance)}`);
            }

            db.updateBalance(message.author.id, -cost);
            db.lottery.pool += cost;
            for (let i = 0; i < count; i++) {
                db.lottery.tickets.push({ userId: message.author.id });
            }
            db.saveLottery();

            const myTickets = db.lottery.tickets.filter(t => t.userId === message.author.id).length;

            return message.reply(
                `🎟️ **${count}** bilet aldın! (${formatMoney(cost)})\n` +
                `Toplam bilet sayın: **${myTickets}**\n` +
                `Güncel ödül havuzu: **${db.lottery.pool.toLocaleString('tr-TR')}**`
            );
        }

        if (sub === 'gecmis' || sub === 'history') {
            if (db.lottery.history.length === 0) {
                return message.reply('Henüz hiç çekiliş yapılmadı.');
            }
            const lines = db.lottery.history.map(h =>
                `<@${h.userId}> — **${h.prize.toLocaleString('tr-TR')}** (${new Date(h.date).toLocaleDateString('tr-TR')})`
            );
            const embed = new EmbedBuilder()
                .setColor('#9b59b6')
                .setTitle('🏆 Son Piyango Kazananları')
                .setDescription(lines.join('\n'));
            return message.reply({ embeds: [embed] });
        }

        const remaining = db.lottery.nextDraw - Date.now();
        const hours = Math.max(0, Math.floor(remaining / 3600000));
        const minutes = Math.max(0, Math.floor((remaining % 3600000) / 60000));
        const myTickets = db.lottery.tickets.filter(t => t.userId === message.author.id).length;

        const embed = new EmbedBuilder()
            .setColor('#9b59b6')
            .setTitle('🎰 Piyango')
            .setDescription(
                `Bilet fiyatı: **${config.LOTTERY_TICKET_PRICE.toLocaleString('tr-TR')}**\n` +
                `Ödül Havuzu: **${db.lottery.pool.toLocaleString('tr-TR')}**\n` +
                `Toplam bilet: **${db.lottery.tickets.length}**\n` +
                `Senin bilet sayın: **${myTickets}**\n` +
                `Sonraki çekiliş: **${hours}s ${minutes}dk**\n\n` +
                `Bilet almak için: \`!piyango al <adet>\`\n` +
                `Geçmiş kazananlar: \`!piyango gecmis\``
            );

        message.reply({ embeds: [embed] });
    }
};
