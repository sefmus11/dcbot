const db = require('../db');
const config = require('../config');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'para',
    aliases: ['bakiye', 'balance'],
    description: 'Bakiyeni gösterir. Kullanım: !para [@kullanıcı]',
    async execute(message) {
        const target = message.mentions.users.first() || message.author;
        const user = db.getUser(target.id);

        const embed = new EmbedBuilder()
            .setColor('#2ecc71')
            .setAuthor({ name: target.username, iconURL: target.displayAvatarURL() })
            .setDescription(`${config.CURRENCY_EMOJI} Bakiye: **${user.balance.toLocaleString('tr-TR')}** ${config.CURRENCY_NAME}`)
            .addFields(
                { name: 'Oynanan Oyun', value: `${user.stats.gamesPlayed}`, inline: true },
                { name: 'Kazanılan', value: `${user.stats.won}`, inline: true },
                { name: 'Kaybedilen', value: `${user.stats.lost}`, inline: true }
            );

        message.reply({ embeds: [embed] });
    }
};
