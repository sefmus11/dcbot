const db = require('../db');
const { parseBet, validateBet, formatMoney } = require('../utils');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'zar',
    aliases: ['dice'],
    description: 'Zar oyunu. Kullanım: !zar <miktar> <tek/cift/1-6>',
    async execute(message, args) {
        const user = db.getUser(message.author.id);
        const amount = parseBet(args[0], user.balance);
        const guess = (args[1] || '').toLowerCase();

        if (!amount) return message.reply('Geçerli bir miktar gir. Örnek: `!zar 1000 tek` veya `!zar 1000 4`');
        const err = validateBet(amount, user.balance);
        if (err) return message.reply(err);

        const roll = Math.floor(Math.random() * 6) + 1;
        let won, multiplier;

        if (guess === 'tek' || guess === 'cift') {
            const isEven = roll % 2 === 0;
            won = (guess === 'cift' && isEven) || (guess === 'tek' && !isEven);
            multiplier = 2; // tek/çift tahmini: 2 katı
        } else if (['1', '2', '3', '4', '5', '6'].includes(guess)) {
            won = parseInt(guess, 10) === roll;
            multiplier = 6; // tam sayı tahmini: 6 katı (daha zor, daha yüksek ödül)
        } else {
            return message.reply('Geçersiz tahmin! `tek`, `cift` veya `1` ile `6` arası bir sayı yaz.');
        }

        const change = won ? amount * (multiplier - 1) : -amount;
        db.updateBalance(message.author.id, change);
        db.recordGame(message.author.id, won);

        const diceEmojis = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
        const embed = new EmbedBuilder()
            .setColor(won ? '#2ecc71' : '#e74c3c')
            .setDescription(
                `${diceEmojis[roll - 1]} Zar: **${roll}**\n` +
                (won ? `Kazandın! +${formatMoney(change)}` : `Kaybettin! -${formatMoney(amount)}`) +
                `\nGüncel bakiye: **${db.getUser(message.author.id).balance.toLocaleString('tr-TR')}**`
            );

        message.reply({ embeds: [embed] });
    }
};
