const db = require('../db');
const { parseBet, validateBet, formatMoney } = require('../utils');
const { EmbedBuilder } = require('discord.js');

const SYMBOLS = [
    { emoji: '🍒', weight: 30, payout: 2 },
    { emoji: '🍋', weight: 25, payout: 3 },
    { emoji: '🍇', weight: 20, payout: 4 },
    { emoji: '🔔', weight: 15, payout: 6 },
    { emoji: '💎', weight: 8, payout: 10 },
    { emoji: '7️⃣', weight: 2, payout: 25 }
];

function spinReel() {
    const totalWeight = SYMBOLS.reduce((s, x) => s + x.weight, 0);
    let r = Math.random() * totalWeight;
    for (const s of SYMBOLS) {
        if (r < s.weight) return s;
        r -= s.weight;
    }
    return SYMBOLS[0];
}

module.exports = {
    name: 'slot',
    aliases: ['slots', 'slotmakinesi'],
    description: 'Slot makinesi. Kullanım: !slot <miktar>',
    async execute(message, args) {
        const user = db.getUser(message.author.id);
        const amount = parseBet(args[0], user.balance);

        if (!amount) return message.reply('Geçerli bir miktar gir. Örnek: `!slot 1000`');
        const err = validateBet(amount, user.balance);
        if (err) return message.reply(err);

        const reels = [spinReel(), spinReel(), spinReel()];
        let won = false;
        let winnings = 0;

        if (reels[0].emoji === reels[1].emoji && reels[1].emoji === reels[2].emoji) {
            won = true;
            winnings = amount * reels[0].payout;
        } else if (
            reels[0].emoji === reels[1].emoji ||
            reels[1].emoji === reels[2].emoji ||
            reels[0].emoji === reels[2].emoji
        ) {
            won = true;
            winnings = Math.floor(amount * 1.5);
        }

        const change = won ? winnings - amount : -amount;
        db.updateBalance(message.author.id, change);
        db.recordGame(message.author.id, won);

        const embed = new EmbedBuilder()
            .setColor(won ? '#2ecc71' : '#e74c3c')
            .setTitle('🎰 Slot Makinesi')
            .setDescription(
                `【 ${reels.map(r => r.emoji).join(' | ')} 】\n\n` +
                (won ? `Kazandın! +${formatMoney(change)}` : `Kaybettin! -${formatMoney(amount)}`) +
                `\nGüncel bakiye: **${db.getUser(message.author.id).balance.toLocaleString('tr-TR')}**`
            );

        message.reply({ embeds: [embed] });
    }
};
