const db = require('./db');
const config = require('./config');
const { EmbedBuilder } = require('discord.js');

function startLotteryScheduler(client, announceChannelId = null) {
    setInterval(async () => {
        if (Date.now() < db.lottery.nextDraw) return;

        if (db.lottery.tickets.length === 0) {
            // Kimse bilet almadıysa çekilişi ertele
            db.lottery.nextDraw = Date.now() + config.LOTTERY_DRAW_INTERVAL;
            db.saveLottery();
            return;
        }

        const winnerTicket = db.lottery.tickets[Math.floor(Math.random() * db.lottery.tickets.length)];
        const prize = db.lottery.pool;

        db.updateBalance(winnerTicket.userId, prize);

        db.lottery.history.unshift({ userId: winnerTicket.userId, prize, date: Date.now() });
        db.lottery.history = db.lottery.history.slice(0, 10);
        db.lottery.pool = 0;
        db.lottery.tickets = [];
        db.lottery.nextDraw = Date.now() + config.LOTTERY_DRAW_INTERVAL;
        db.saveLottery();

        if (announceChannelId) {
            const channel = await client.channels.fetch(announceChannelId).catch(() => null);
            if (channel) {
                const embed = new EmbedBuilder()
                    .setColor('#f1c40f')
                    .setTitle('🎉 Piyango Çekilişi Sonucu')
                    .setDescription(`Kazanan: <@${winnerTicket.userId}>\nÖdül: **${prize.toLocaleString('tr-TR')}** 💰`);
                channel.send({ embeds: [embed] }).catch(() => {});
            }
        }
    }, 60 * 1000); // her dakika çekiliş zamanı gelip gelmediğini kontrol eder
}

module.exports = { startLotteryScheduler };
