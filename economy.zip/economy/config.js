module.exports = {
    PREFIX: '!',
    MAX_BET: 250000,           // Tüm oyunlar için maksimum bahis
    MIN_BET: 10,                // Minimum bahis
    DAILY_MIN: 500,             // Günlük ödül min
    DAILY_MAX: 2000,            // Günlük ödül max
    DAILY_COOLDOWN: 24 * 60 * 60 * 1000, // 24 saat
    STARTING_BALANCE: 1000,     // Yeni kullanıcı başlangıç bakiyesi
    LOTTERY_TICKET_PRICE: 1000, // Piyango bilet fiyatı
    LOTTERY_DRAW_INTERVAL: 24 * 60 * 60 * 1000, // 24 saatte bir çekiliş
    CURRENCY_NAME: 'Para',
    CURRENCY_EMOJI: '💰'
};
