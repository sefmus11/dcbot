const config = require('./config');

function parseBet(input, userBalance) {
    if (!input) return null;
    const lower = input.toLowerCase();
    let amount;
    if (lower === 'hepsi' || lower === 'all' || lower === 'max') {
        amount = userBalance;
    } else {
        amount = parseInt(input.replace(/\./g, '').replace(/,/g, ''), 10);
    }
    if (isNaN(amount) || amount <= 0) return null;
    return amount;
}

function validateBet(amount, userBalance) {
    if (amount < config.MIN_BET) return `Minimum bahis **${config.MIN_BET.toLocaleString('tr-TR')}**.`;
    if (amount > config.MAX_BET) return `Maksimum bahis **${config.MAX_BET.toLocaleString('tr-TR')}**.`;
    if (amount > userBalance) return `Yeterli bakiyen yok! Bakiyen: **${userBalance.toLocaleString('tr-TR')}**.`;
    return null;
}

function formatMoney(n) {
    return `${n.toLocaleString('tr-TR')} ${config.CURRENCY_EMOJI}`;
}

module.exports = { parseBet, validateBet, formatMoney };
